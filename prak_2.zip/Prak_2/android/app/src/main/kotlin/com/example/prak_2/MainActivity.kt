package com.example.prak_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
